<?php
/**
 * @package modx
 */
class modAccessTemplateVar extends modAccessElement {}