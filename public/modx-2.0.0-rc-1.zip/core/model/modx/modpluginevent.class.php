<?php
/**
 * Represents a plugin registered for a specific event.
 *
 * @package modx
 */
class modPluginEvent extends xPDOObject {}