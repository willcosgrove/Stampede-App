<?php
/**
 * Represents a relationship between a template and a template variable.
 *
 * @package modx
 */
class modTemplateVarTemplate extends xPDOObject {}