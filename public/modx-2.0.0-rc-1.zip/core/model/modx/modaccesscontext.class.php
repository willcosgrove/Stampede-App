<?php
/**
 * @package modx
 */
class modAccessContext extends modAccess {}