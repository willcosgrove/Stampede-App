<?php
/**
 * @package modx
 */
class modResourceGroupResource extends xPDOSimpleObject {}