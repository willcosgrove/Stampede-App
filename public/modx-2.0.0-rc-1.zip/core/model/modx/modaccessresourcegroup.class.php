<?php
/**
 * Defines an access control policy between a principal and a modResourceGroup.
 *
 * {@inheritdoc}
 *
 * @package modx
 */
class modAccessResourceGroup extends modAccess {}