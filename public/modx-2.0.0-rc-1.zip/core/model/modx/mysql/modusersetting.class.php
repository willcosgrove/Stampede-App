<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modusersetting.class.php');
class modUserSetting_mysql extends modUserSetting {}