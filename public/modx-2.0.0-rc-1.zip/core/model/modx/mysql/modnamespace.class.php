<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modnamespace.class.php');
class modNamespace_mysql extends modNamespace {}