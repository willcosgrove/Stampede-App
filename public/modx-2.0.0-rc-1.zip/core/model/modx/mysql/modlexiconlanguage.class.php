<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modlexiconlanguage.class.php');
class modLexiconLanguage_mysql extends modLexiconLanguage {}