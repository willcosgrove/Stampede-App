<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modaccesspolicy.class.php');
class modAccessPolicy_mysql extends modAccessPolicy {}