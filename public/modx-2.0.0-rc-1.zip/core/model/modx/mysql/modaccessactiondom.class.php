<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modaccessactiondom.class.php');
class modAccessActionDom_mysql extends modAccessActionDom {}