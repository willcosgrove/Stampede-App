<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modaccessmenu.class.php');
class modAccessMenu_mysql extends modAccessMenu {}