<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modmetatag.class.php');
class modMetatag_mysql extends modMetatag {}