<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modaccesscontext.class.php');
class modAccessContext_mysql extends modAccessContext {}