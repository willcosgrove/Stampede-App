<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modsymlink.class.php');
class modSymLink_mysql extends modSymLink {}