<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modpropertyset.class.php');
class modPropertySet_mysql extends modPropertySet {}