<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modworkspace.class.php');
class modWorkspace_mysql extends modWorkspace {}