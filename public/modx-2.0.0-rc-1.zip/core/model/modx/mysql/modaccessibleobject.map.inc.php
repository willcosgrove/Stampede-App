<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['modAccessibleObject']= array (
  'package' => 'modx',
);
