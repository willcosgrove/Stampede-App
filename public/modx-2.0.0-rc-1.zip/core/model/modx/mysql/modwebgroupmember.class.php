<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modwebgroupmember.class.php');
class modWebGroupMember_mysql extends modWebGroupMember {}