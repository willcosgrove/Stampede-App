<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['modAccessibleSimpleObject']= array (
  'package' => 'modx',
  'fields' => 
  array (
    'id' => NULL,
  ),
  'fieldMeta' => 
  array (
    'id' => 
    array (
      'dbtype' => 'int',
      'precision' => '10',
      'attributes' => 'unsigned',
      'phptype' => 'integer',
      'null' => false,
      'index' => 'pk',
      'generated' => 'native',
    ),
  ),
);
