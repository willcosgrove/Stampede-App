<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modwebusersetting.class.php');
class modWebUserSetting_mysql extends modWebUserSetting {}