<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modresourcekeyword.class.php');
class modResourceKeyword_mysql extends modResourceKeyword {}