<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modmanageruser.class.php');
class modManagerUser_mysql extends modManagerUser {}