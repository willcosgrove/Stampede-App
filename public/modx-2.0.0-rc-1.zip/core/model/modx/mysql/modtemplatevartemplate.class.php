<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modtemplatevartemplate.class.php');
class modTemplateVarTemplate_mysql extends modTemplateVarTemplate {}