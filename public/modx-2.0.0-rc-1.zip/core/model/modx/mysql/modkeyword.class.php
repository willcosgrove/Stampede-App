<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modkeyword.class.php');
class modKeyword_mysql extends modKeyword {}