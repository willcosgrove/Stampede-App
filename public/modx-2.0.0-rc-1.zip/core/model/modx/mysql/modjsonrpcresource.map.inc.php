<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['modJSONRPCResource']= array (
  'package' => 'modx',
);
