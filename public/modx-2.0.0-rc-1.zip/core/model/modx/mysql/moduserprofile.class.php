<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../moduserprofile.class.php');
class modUserProfile_mysql extends modUserProfile {}