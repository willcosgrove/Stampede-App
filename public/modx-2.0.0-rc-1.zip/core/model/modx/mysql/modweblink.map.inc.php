<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['modWebLink']= array (
  'package' => 'modx',
);
