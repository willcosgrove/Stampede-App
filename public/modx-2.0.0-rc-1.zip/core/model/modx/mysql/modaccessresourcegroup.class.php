<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modaccessresourcegroup.class.php');
class modAccessResourceGroup_mysql extends modAccessResourceGroup {}