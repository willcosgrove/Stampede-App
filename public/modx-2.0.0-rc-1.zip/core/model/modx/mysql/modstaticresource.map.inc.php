<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['modStaticResource']= array (
  'package' => 'modx',
);
