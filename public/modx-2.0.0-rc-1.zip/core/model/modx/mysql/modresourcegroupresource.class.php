<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modresourcegroupresource.class.php');
class modResourceGroupResource_mysql extends modResourceGroupResource {}