<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modweblink.class.php');
class modWebLink_mysql extends modWebLink {}