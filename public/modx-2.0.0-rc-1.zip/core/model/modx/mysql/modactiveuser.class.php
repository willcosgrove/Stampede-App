<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modactiveuser.class.php');
class modActiveUser_mysql extends modActiveUser {}