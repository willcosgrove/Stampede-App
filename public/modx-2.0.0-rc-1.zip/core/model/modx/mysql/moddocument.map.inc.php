<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['modDocument']= array (
  'package' => 'modx',
);
