<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modusermessage.class.php');
class modUserMessage_mysql extends modUserMessage {}