<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modusergroupdocumentgroup.class.php');
class modUserGroupDocumentGroup_mysql extends modUserGroupDocumentGroup {}