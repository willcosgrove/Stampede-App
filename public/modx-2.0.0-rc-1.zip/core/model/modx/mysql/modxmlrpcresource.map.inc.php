<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['modXMLRPCResource']= array (
  'package' => 'modx',
);
