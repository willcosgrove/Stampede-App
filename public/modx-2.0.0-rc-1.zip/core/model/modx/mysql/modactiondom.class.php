<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modactiondom.class.php');
class modActionDom_mysql extends modActionDom {}