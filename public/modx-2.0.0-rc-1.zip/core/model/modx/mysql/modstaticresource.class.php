<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modstaticresource.class.php');
class modStaticResource_mysql extends modStaticResource {}