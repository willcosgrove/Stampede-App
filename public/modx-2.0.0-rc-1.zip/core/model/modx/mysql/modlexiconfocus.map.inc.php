<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['modLexiconFocus']= array (
  'package' => 'modx',
);
