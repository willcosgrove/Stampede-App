<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modlexiconfocus.class.php');
class modLexiconFocus_mysql extends modLexiconFocus {}