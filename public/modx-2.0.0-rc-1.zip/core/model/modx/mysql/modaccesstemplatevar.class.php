<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modaccesstemplatevar.class.php');
class modAccessTemplateVar_mysql extends modAccessTemplateVar {}