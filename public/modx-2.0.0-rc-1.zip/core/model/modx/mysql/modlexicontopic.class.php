<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modlexicontopic.class.php');
class modLexiconTopic_mysql extends modLexiconTopic {}