<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modpluginevent.class.php');
class modPluginEvent_mysql extends modPluginEvent {}