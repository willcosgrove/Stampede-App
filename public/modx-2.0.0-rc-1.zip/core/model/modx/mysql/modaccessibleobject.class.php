<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modaccessibleobject.class.php');
class modAccessibleObject_mysql extends modAccessibleObject {}