<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modresourcegroup.class.php');
class modResourceGroup_mysql extends modResourceGroup {}