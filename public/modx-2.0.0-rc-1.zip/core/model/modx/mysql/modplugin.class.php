<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modplugin.class.php');
class modPlugin_mysql extends modPlugin {}