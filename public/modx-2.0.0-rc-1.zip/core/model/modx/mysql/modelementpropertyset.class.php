<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modelementpropertyset.class.php');
class modElementPropertySet_mysql extends modElementPropertySet {}