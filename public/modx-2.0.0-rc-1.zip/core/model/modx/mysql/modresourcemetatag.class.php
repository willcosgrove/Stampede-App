<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modresourcemetatag.class.php');
class modResourceMetatag_mysql extends modResourceMetatag {}