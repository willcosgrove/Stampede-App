<?php
/**
 * @package modx
 * @subpackage mysql
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modmanagerlog.class.php');
class modManagerLog_mysql extends modManagerLog {}