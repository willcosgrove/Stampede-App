<?php
/**
 * @package modx
 * @subpackage mysql
 */
include_once (strtr(realpath(dirname(__FILE__)), '\\', '/') . '/../modtemplatevar.class.php');
class modTemplateVar_mysql extends modTemplateVar {}