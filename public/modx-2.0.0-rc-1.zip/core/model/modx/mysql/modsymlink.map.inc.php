<?php
/**
 * @package modx
 * @subpackage mysql
 */
$xpdo_meta_map['modSymLink']= array (
  'package' => 'modx',
);
