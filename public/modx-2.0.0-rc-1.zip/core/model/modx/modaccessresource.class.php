<?php
/**
 * Defines an access control policy between a principal and a modResource.
 *
 * {@inheritdoc}
 *
 * @package modx
 */
class modAccessResource extends modAccess {}