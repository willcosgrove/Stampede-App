<?php
/**
 * Represents a user membership in a user group.
 *
 * @package modx
 */
class modUserGroupMember extends xPDOSimpleObject {}