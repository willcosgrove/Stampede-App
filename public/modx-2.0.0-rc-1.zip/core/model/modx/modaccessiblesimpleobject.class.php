<?php
/**
 * @package modx
 */
class modAccessibleSimpleObject extends modAccessibleObject {}