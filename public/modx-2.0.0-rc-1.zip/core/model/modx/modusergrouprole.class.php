<?php
/**
 * @package modx
 */
class modUserGroupRole extends xPDOSimpleObject {}