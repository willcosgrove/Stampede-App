<?php
/**
 * Represents a user group with access to a resource group.
 *
 * @package modx
 */
class modUserGroupDocumentGroup extends xPDOSimpleObject {}