<?php
/**
 * Represents extended user profile data.
 *
 * @package modx
 */
class modUserProfile extends xPDOSimpleObject {}