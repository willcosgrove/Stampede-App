<?php
/**
 * Restricts or grants access to certain functionality. Grouped by Access
 * Policy.
 *
 * @package modx
 */
class modAccessPermission extends xPDOSimpleObject {}