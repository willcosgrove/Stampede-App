<?php
/**
 * @package modx
 * @deprecated 2.0.0
 */
class modResourceKeyword extends xPDOObject {}