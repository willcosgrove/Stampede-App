<?php
/**
 * Represents MODx 0.9.6.x manager user records for migration only.
 *
 * DO NOT USE! This class is intended only for use in the migration tool from
 * previous versions of MODx.
 *
 * @deprecated 2007-09-19 To be removed in 1.0
 * @package modx
 */
class modManagerUser extends modUser {}