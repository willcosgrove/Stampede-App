<?php
/**
 * @package modx
 */
class modTemplateVarResource extends xPDOSimpleObject {}