<?php
/**
 * Represents a legacy web_user_attributes entity.
 *
 * @deprecated 2007-09-20 For migration purposes only.
 * @package modx
 */
class modWebUserProfile extends xPDOSimpleObject {}