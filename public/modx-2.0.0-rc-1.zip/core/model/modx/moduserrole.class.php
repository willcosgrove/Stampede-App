<?php
/**
 * Represents a set of user permissions defining a role.
 *
 * @package modx
 */
class modUserRole extends xPDOSimpleObject {}