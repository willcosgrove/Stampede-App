<?php
/**
 * @package modx
 */
class modAccessActionDom extends modAccess {}