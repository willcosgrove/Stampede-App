<?php
/**
 * @package modx
 */
class modTemplateVarResourceGroup extends xPDOSimpleObject {}