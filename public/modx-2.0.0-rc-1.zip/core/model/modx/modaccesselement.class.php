<?php
/**
 * @package modx
 */
class modAccessElement extends modAccess {}