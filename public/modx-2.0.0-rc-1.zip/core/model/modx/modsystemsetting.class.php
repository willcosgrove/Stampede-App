<?php
/**
 * Represents a system configuration setting.
 *
 * @package modx
 */
class modSystemSetting extends xPDOObject {}