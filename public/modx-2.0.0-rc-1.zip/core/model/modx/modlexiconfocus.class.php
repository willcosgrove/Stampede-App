<?php
/**
 * @deprecated 2.0.0-alpha-6 - Nov 1, 2008
 * @package modx
 */
class modLexiconFocus extends modLexiconTopic {}