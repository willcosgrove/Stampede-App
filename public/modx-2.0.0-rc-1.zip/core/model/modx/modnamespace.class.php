<?php
/**
 * modNamespace
 *
 * @package modx
 */
/**
 * Represents a Component in the MODx framework.
 *
 * @package modx
 */
class modNamespace extends xPDOObject {}