<?php
/**
 * Defines criteria a principal must satisfy in order to access an object.
 *
 * @package modx
 */
class modAccessPolicy extends xPDOSimpleObject {}