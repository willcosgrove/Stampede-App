<?php
/**
 * Represents a user setting which overrides system and context settings.
 *
 * @package modx
 */
class modUserSetting extends xPDOObject {}