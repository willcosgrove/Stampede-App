<?php
/**
 * @package modx
 */
class modManagerLog extends xPDOSimpleObject {}